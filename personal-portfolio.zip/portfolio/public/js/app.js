// public/js/app.js
// Vanilla JS — talks to the Express API at /api/* (same origin).
// If you split frontend/backend onto different hosts (e.g. Netlify +
// Render), set API_BASE below to the backend's full URL.
const API_BASE = '';

document.getElementById('year').textContent = new Date().getFullYear();

/* ---------- Mobile nav ---------- */
const navToggle = document.querySelector('.nav-toggle');
const siteNav = document.querySelector('.site-nav');
if (navToggle) {
  navToggle.addEventListener('click', () => {
    const open = siteNav.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(open));
  });
}

/* ---------- Projects ---------- */
let allProjects = [];

async function loadProjects() {
  const grid = document.getElementById('projects-grid');
  try {
    const res = await fetch(`${API_BASE}/api/projects`);
    if (!res.ok) throw new Error(`API error ${res.status}`);
    allProjects = await res.json();
    renderProjects('all');
    renderStats(allProjects);
  } catch (err) {
    grid.innerHTML = `<p class="empty-note">Couldn't load projects right now (${err.message}). Make sure the API server is running.</p>`;
  }
}

function renderProjects(filter) {
  const grid = document.getElementById('projects-grid');
  const list = filter === 'featured' ? allProjects.filter((p) => p.featured) : allProjects;

  if (!list.length) {
    grid.innerHTML = '<p class="empty-note">No projects to show yet — add some via the API.</p>';
    return;
  }

  grid.innerHTML = list
    .map((p, i) => {
      const tech = (p.techStack || [])
        .map((t) => `<span class="tech-pill">${escapeHtml(t)}</span>`)
        .join('');
      const links = [
        p.githubUrl ? `<a href="${escapeAttr(p.githubUrl)}" target="_blank" rel="noopener">Code →</a>` : '',
        p.liveUrl ? `<a href="${escapeAttr(p.liveUrl)}" target="_blank" rel="noopener">Live →</a>` : '',
      ].join('');
      return `
        <article class="project-card">
          <span class="idx">FIG. ${String(i + 1).padStart(2, '0')}</span>
          <h3>${escapeHtml(p.title)}</h3>
          <p>${escapeHtml(p.description)}</p>
          <div class="tech-row">${tech}</div>
          ${links ? `<div class="project-links">${links}</div>` : ''}
        </article>`;
    })
    .join('');
}

document.getElementById('filter-row').addEventListener('click', (e) => {
  const btn = e.target.closest('.chip');
  if (!btn) return;
  document.querySelectorAll('.chip').forEach((c) => c.classList.remove('is-active'));
  btn.classList.add('is-active');
  renderProjects(btn.dataset.filter);
});

function renderStats(projects) {
  const stack = new Set();
  projects.forEach((p) => (p.techStack || []).forEach((t) => stack.add(t)));
  const stats = [
    { num: projects.length, label: 'Projects shipped' },
    { num: stack.size, label: 'Technologies used' },
    { num: projects.filter((p) => p.featured).length, label: 'Featured builds' },
    { num: '2025–29', label: 'B.Tech AI & DS' },
  ];
  document.getElementById('stats-grid').innerHTML = stats
    .map((s) => `<div class="stat"><span class="num">${s.num}</span><span class="label">${s.label}</span></div>`)
    .join('');
}

/* ---------- Skills ---------- */
async function loadSkills() {
  const board = document.getElementById('skills-board');
  try {
    const res = await fetch(`${API_BASE}/api/skills`);
    if (!res.ok) throw new Error(`API error ${res.status}`);
    const grouped = await res.json();
    const categories = Object.keys(grouped);
    if (!categories.length) {
      board.innerHTML = '<p class="empty-note">No skills listed yet.</p>';
      return;
    }
    board.innerHTML = categories
      .map((cat) => {
        const rows = grouped[cat]
          .map((s) => {
            const dots = Array.from({ length: 5 }, (_, i) =>
              `<span class="dot ${i < s.level ? 'filled' : ''}"></span>`
            ).join('');
            return `<div class="skill-row"><span>${escapeHtml(s.name)}</span><span class="skill-dots">${dots}</span></div>`;
          })
          .join('');
        return `<div class="skill-col"><h3>${escapeHtml(cat)}</h3>${rows}</div>`;
      })
      .join('');
  } catch (err) {
    board.innerHTML = `<p class="empty-note">Couldn't load skills right now (${err.message}).</p>`;
  }
}

/* ---------- Contact form ---------- */
const form = document.getElementById('contact-form');
const status = document.getElementById('form-status');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  status.textContent = 'Sending…';
  const data = Object.fromEntries(new FormData(form).entries());
  try {
    const res = await fetch(`${API_BASE}/api/contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || 'Something went wrong');
    status.textContent = body.message || 'Message sent — thank you!';
    form.reset();
  } catch (err) {
    status.textContent = `Error: ${err.message}`;
  }
});

/* ---------- helpers ---------- */
function escapeHtml(str = '') {
  return str.replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}
function escapeAttr(str = '') {
  return escapeHtml(str);
}

loadProjects();
loadSkills();
