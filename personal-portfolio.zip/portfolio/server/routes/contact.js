// server/routes/contact.js
import { Router } from 'express';
import db from '../db.js';
import { randomUUID } from 'crypto';

const router = Router();

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// POST /api/contact - store a message from the contact form
router.post('/', async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'name, email and message are required' });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'Please provide a valid email address' });
  }
  await db.read();
  const entry = {
    id: randomUUID(),
    name,
    email,
    message,
    read: false,
    createdAt: new Date().toISOString(),
  };
  db.data.messages.push(entry);
  await db.write();
  res.status(201).json({ ok: true, message: 'Thanks for reaching out — I will get back to you soon.' });
});

// GET /api/contact - list messages (simple admin view; protect this in production)
router.get('/', async (req, res) => {
  await db.read();
  res.json([...db.data.messages].reverse());
});

export default router;
