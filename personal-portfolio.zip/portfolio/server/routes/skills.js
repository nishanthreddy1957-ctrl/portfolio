// server/routes/skills.js
import { Router } from 'express';
import db from '../db.js';
import { randomUUID } from 'crypto';

const router = Router();

// GET /api/skills - grouped by category
router.get('/', async (req, res) => {
  await db.read();
  const grouped = {};
  for (const skill of db.data.skills) {
    grouped[skill.category] ||= [];
    grouped[skill.category].push(skill);
  }
  res.json(grouped);
});

// POST /api/skills
router.post('/', async (req, res) => {
  const { name, category, level } = req.body;
  if (!name || !category) {
    return res.status(400).json({ error: 'name and category are required' });
  }
  await db.read();
  const skill = { id: randomUUID(), name, category, level: level ?? 3 };
  db.data.skills.push(skill);
  await db.write();
  res.status(201).json(skill);
});

// DELETE /api/skills/:id
router.delete('/:id', async (req, res) => {
  await db.read();
  const before = db.data.skills.length;
  db.data.skills = db.data.skills.filter((s) => s.id !== req.params.id);
  if (db.data.skills.length === before) {
    return res.status(404).json({ error: 'Skill not found' });
  }
  await db.write();
  res.status(204).end();
});

export default router;
