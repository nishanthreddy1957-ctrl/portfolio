// server/routes/projects.js
import { Router } from 'express';
import db from '../db.js';
import { randomUUID } from 'crypto';

const router = Router();

// GET /api/projects - list all, optional ?featured=true
router.get('/', async (req, res) => {
  await db.read();
  let projects = db.data.projects;
  if (req.query.featured === 'true') {
    projects = projects.filter((p) => p.featured);
  }
  projects = [...projects].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  res.json(projects);
});

// GET /api/projects/:id
router.get('/:id', async (req, res) => {
  await db.read();
  const project = db.data.projects.find((p) => p.id === req.params.id);
  if (!project) return res.status(404).json({ error: 'Project not found' });
  res.json(project);
});

// POST /api/projects - create
router.post('/', async (req, res) => {
  const { title, description, techStack, imageUrl, githubUrl, liveUrl, featured, order } = req.body;
  if (!title || !description) {
    return res.status(400).json({ error: 'title and description are required' });
  }
  await db.read();
  const project = {
    id: randomUUID(),
    title,
    description,
    techStack: Array.isArray(techStack) ? techStack : [],
    imageUrl: imageUrl || '',
    githubUrl: githubUrl || '',
    liveUrl: liveUrl || '',
    featured: !!featured,
    order: typeof order === 'number' ? order : db.data.projects.length,
    createdAt: new Date().toISOString(),
  };
  db.data.projects.push(project);
  await db.write();
  res.status(201).json(project);
});

// PUT /api/projects/:id - update
router.put('/:id', async (req, res) => {
  await db.read();
  const idx = db.data.projects.findIndex((p) => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Project not found' });
  db.data.projects[idx] = { ...db.data.projects[idx], ...req.body, id: req.params.id };
  await db.write();
  res.json(db.data.projects[idx]);
});

// DELETE /api/projects/:id
router.delete('/:id', async (req, res) => {
  await db.read();
  const before = db.data.projects.length;
  db.data.projects = db.data.projects.filter((p) => p.id !== req.params.id);
  if (db.data.projects.length === before) {
    return res.status(404).json({ error: 'Project not found' });
  }
  await db.write();
  res.status(204).end();
});

export default router;
