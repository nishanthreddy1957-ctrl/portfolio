// server/seed.js
// Run with: npm run seed
// Populates the database with sample data so the site looks complete
// out of the box. Edit the arrays below with your own projects/skills,
// or manage them later via the REST API / a small admin script.

import { initDB } from './db.js';
import db from './db.js';

const projects = [
  {
    title: 'Bluestock MF — Mutual Fund Analytics Platform',
    description: 'End-to-end data engineering and analytics pipeline for mutual fund data: synthetic data generation, a SQLite star schema (fact/dimension tables), 10+ analytical SQL queries, and a full EDA notebook with 15+ visualizations covering NAV trends, AUM growth, SIP inflows, and investor demographics.',
    techStack: ['Python', 'SQLite', 'Pandas', 'Plotly', 'Seaborn', 'Matplotlib'],
    imageUrl: '',
    githubUrl: '',
    liveUrl: '',
    featured: true,
    order: 0,
  },
  {
    title: 'AI Campus FAQ Chatbot',
    description: 'A conversational chatbot that answers common student queries about campus services, built and deployed as part of a hackathon project, with intent classification and a simple retrieval-based response engine.',
    techStack: ['Python', 'NLP', 'Flask'],
    imageUrl: '',
    githubUrl: '',
    liveUrl: '',
    featured: true,
    order: 1,
  },
  {
    title: 'AI Resume Analyser',
    description: 'Parses uploaded resumes and scores them against a target job description, surfacing missing keywords and skill gaps to help candidates improve their applications.',
    techStack: ['Python', 'NLP', 'scikit-learn'],
    imageUrl: '',
    githubUrl: '',
    liveUrl: '',
    featured: false,
    order: 2,
  },
  {
    title: 'NLP Text Summariser',
    description: 'Extractive and abstractive text summarisation tool for long-form articles, built to compare classical NLP techniques against transformer-based approaches.',
    techStack: ['Python', 'NLTK', 'Transformers'],
    imageUrl: '',
    githubUrl: '',
    liveUrl: '',
    featured: false,
    order: 3,
  },
  {
    title: 'IoT Smart Attendance System',
    description: 'Automated attendance tracking system using IoT sensors and a connected dashboard, reducing manual roll-call time in classroom settings.',
    techStack: ['IoT', 'Python', 'SQL'],
    imageUrl: '',
    githubUrl: '',
    liveUrl: '',
    featured: false,
    order: 4,
  },
];

const skills = [
  // Languages
  { name: 'Python', category: 'Languages', level: 5 },
  { name: 'SQL', category: 'Languages', level: 4 },
  { name: 'JavaScript', category: 'Languages', level: 3 },

  // Data & Analytics
  { name: 'Pandas / NumPy', category: 'Data & Analytics', level: 5 },
  { name: 'Power BI / Tableau', category: 'Data & Analytics', level: 4 },
  { name: 'IBM SPSS', category: 'Data & Analytics', level: 3 },
  { name: 'Statistical Analysis', category: 'Data & Analytics', level: 4 },

  // ML / AI
  { name: 'scikit-learn', category: 'ML & AI', level: 4 },
  { name: 'NLP', category: 'ML & AI', level: 4 },

  // Tools
  { name: 'Excel', category: 'Tools', level: 5 },
  { name: 'Git / GitHub', category: 'Tools', level: 4 },
  { name: 'SQLite / MySQL', category: 'Tools', level: 4 },
];

async function seed() {
  await initDB();
  db.data.projects = projects.map((p, i) => ({
    id: `seed-project-${i}`,
    createdAt: new Date().toISOString(),
    ...p,
  }));
  db.data.skills = skills.map((s, i) => ({ id: `seed-skill-${i}`, ...s }));
  db.data.messages = db.data.messages || [];
  await db.write();
  console.log(`Seeded ${projects.length} projects and ${skills.length} skills.`);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
