// server/db.js
// Lightweight JSON-file "database" using lowdb.
// Why lowdb for the default setup: it requires no native compilation and
// no external DB server, so the project runs identically on your laptop,
// in this sandbox, and on free hosting tiers (Render/Railway/Vercel).
//
// Want real MySQL / PostgreSQL / MongoDB instead?
// See server/db-mongo.js for a drop-in Mongoose version, and README.md
// "Switching to a production database" for the two-line swap.

import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const file = path.join(__dirname, 'data', 'db.json');

const defaultData = { projects: [], skills: [], messages: [] };

const adapter = new JSONFile(file);
const db = new Low(adapter, defaultData);

export async function initDB() {
  await db.read();
  db.data ||= defaultData;
  await db.write();
  return db;
}

export default db;
