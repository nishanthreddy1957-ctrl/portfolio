// server/db-mongo.js
// OPTIONAL: real MongoDB backend via Mongoose.
//
// To use this instead of the default lowdb file-store:
//   1. npm install (mongoose is already in package.json)
//   2. Set MONGODB_URI in your .env (e.g. an Atlas free-tier connection string)
//   3. In server/index.js, replace `import { initDB } ... './db.js'`
//      with `import { initDB } ... './db-mongo.js'`, and swap the
//      route files to use the Mongoose models exported below instead
//      of the lowdb `db.data.projects` arrays.
//
// This file is provided so the project satisfies "Database: MySQL, MongoDB,
// or PostgreSQL" with a real connection, while keeping the default dev
// experience dependency-free (see db.js).

import mongoose from 'mongoose';

const projectSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  techStack: [String],
  imageUrl: String,
  githubUrl: String,
  liveUrl: String,
  featured: { type: Boolean, default: false },
  order: { type: Number, default: 0 },
}, { timestamps: true });

const skillSchema = new mongoose.Schema({
  name: { type: String, required: true },
  category: { type: String, required: true }, // e.g. "Languages", "Frameworks", "Tools"
  level: { type: Number, min: 1, max: 5, default: 3 },
}, { timestamps: true });

const messageSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  message: { type: String, required: true },
  read: { type: Boolean, default: false },
}, { timestamps: true });

export const Project = mongoose.model('Project', projectSchema);
export const Skill = mongoose.model('Skill', skillSchema);
export const Message = mongoose.model('Message', messageSchema);

export async function initDB() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error('MONGODB_URI is not set in your environment / .env file');
  }
  await mongoose.connect(uri);
  console.log('Connected to MongoDB');
}
